/**
 * Theme: Metrica - Responsive Bootstrap 4 Admin Dashboard
 * Author: Mannatthemes
 * News Js
 */


$('.js-conveyor-example').jConveyorTicker({reverse_elm: true});